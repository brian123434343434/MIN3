﻿
Partial Class MasterPages_SecurityDefault
    Inherits System.Web.UI.MasterPage
End Class

